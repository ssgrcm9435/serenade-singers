export default function BlogPage() {
  return (
    <main className="container">

      <p className="eyebrow">
        Serenade Singers
      </p>

      <h1 className="section-title">
        Blog
      </h1>

      <p className="section-text">
        Modern premium blog section for Serenade Singers.
      </p>

      <div className="grid">

        <div className="card">
          <h3>Blog Section 1</h3>

          <p>
            Easily add and manage content for this section.
          </p>
        </div>

        <div className="card">
          <h3>Blog Section 2</h3>

          <p>
            Premium modern layout with responsive structure.
          </p>
        </div>

        <div className="card">
          <h3>Blog Section 3</h3>

          <p>
            Add images, member profiles, events, blogs, or classes.
          </p>
        </div>

      </div>

    </main>
  );
}
